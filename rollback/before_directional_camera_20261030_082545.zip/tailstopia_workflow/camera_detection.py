"""Detect part of the blue tent in a bounded checkpoint ROI, not its exact pose."""
from dataclasses import dataclass

import cv2
import numpy as np

from .start_detection import StartDetector


@dataclass(frozen=True)
class CameraObservation:
    aligned: bool
    blue_pixels: int
    blob_pixels: int
    point: tuple | None


class CameraDetector:
    def __init__(self, config, base):
        cv2.setNumThreads(1)
        self.config = config
        self.roi = StartDetector._box(config["search_roi_client"])
        self.lower = np.array(config["blue_hsv_lower"],dtype=np.uint8)
        self.upper = np.array(config["blue_hsv_upper"],dtype=np.uint8)

    def inspect(self, image):
        rgb = np.array(image.convert("RGB"))
        if rgb.shape[:2] != (self.roi[3]-self.roi[1],self.roi[2]-self.roi[0]):
            raise ValueError("Camera capture dimensions differ from ROI")
        mask = cv2.inRange(cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV),self.lower,self.upper)
        blue_pixels = int(cv2.countNonZero(mask))
        # A small connected patch is enough: no full tent/center alignment.
        # Reject scattered blue pixels (noise, text) without another capture.
        count,_,stats,centers = cv2.connectedComponentsWithStats(mask,connectivity=8)
        if count <= 1:
            return CameraObservation(False,blue_pixels,0,None)
        index = 1+int(np.argmax(stats[1:,cv2.CC_STAT_AREA]))
        blob_pixels = int(stats[index,cv2.CC_STAT_AREA])
        point = (self.roi[0]+int(round(centers[index][0])),
                 self.roi[1]+int(round(centers[index][1])))
        return CameraObservation(blob_pixels >= self.config["min_blue_blob_pixels"],blue_pixels,blob_pixels,point)

    def observe(self,capture):
        with capture(self.roi) as image:
            return self.inspect(image)
