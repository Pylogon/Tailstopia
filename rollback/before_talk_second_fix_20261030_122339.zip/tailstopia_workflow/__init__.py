"""Offline workflow simulation."""
