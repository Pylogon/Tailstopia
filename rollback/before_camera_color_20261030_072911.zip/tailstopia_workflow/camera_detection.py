"""One small, stationary landmark capture per camera calibration observation."""
from dataclasses import dataclass
from pathlib import Path
import math

import cv2
import numpy as np
from PIL import Image

from .start_detection import StartDetector


@dataclass(frozen=True)
class CameraObservation:
    aligned: bool
    score: float
    point: tuple
    position_error: float


class CameraDetector:
    def __init__(self, config, base):
        cv2.setNumThreads(1)
        self.config = config
        self.roi = StartDetector._box(config["search_roi_client"])
        box = StartDetector._box(config["template_box_client"])
        origin = config["reference_client_origin"]
        with Image.open(Path(base) / config["reference_image"]) as image:
            area = (box[0]+origin[0],box[1]+origin[1],box[2]+origin[0],box[3]+origin[1])
            if area[2] > image.width or area[3] > image.height:
                raise ValueError("Camera template outside reference image")
            self.template = np.array(image.crop(area).convert("L"))
        if self.template.std() < 1:
            raise ValueError("Camera landmark must have visible detail")
        self.expected_point = (box[0]+self.template.shape[1]//2,box[1]+self.template.shape[0]//2)

    def inspect(self, image):
        gray = np.array(image.convert("L"))
        if gray.shape != (self.roi[3]-self.roi[1],self.roi[2]-self.roi[0]):
            raise ValueError("Camera capture dimensions differ from ROI")
        scores = cv2.matchTemplate(gray,self.template,cv2.TM_CCOEFF_NORMED)
        scores[~np.isfinite(scores) | (np.abs(scores) > 1.0001)] = -1.0
        _,score,_,point = cv2.minMaxLoc(scores)
        score = max(0.0,min(1.0,float(score)))
        center = (self.roi[0]+point[0]+self.template.shape[1]//2,
                  self.roi[1]+point[1]+self.template.shape[0]//2)
        error = math.hypot(center[0]-self.expected_point[0],center[1]-self.expected_point[1])
        aligned = score >= self.config["threshold"] and error <= self.config["position_tolerance_pixels"]
        return CameraObservation(aligned,score,center,error)

    def observe(self,capture):
        with capture(self.roi) as image:
            return self.inspect(image)
