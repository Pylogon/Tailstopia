"""Small-ROI OpenCV templates for note.txt's UI, plus reward change detection."""
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .start_detection import StartDetector


@dataclass(frozen=True)
class Match:
    found: bool
    score: float
    point: tuple | None


class MissionVision:
    def __init__(self, config, base):
        cv2.setNumThreads(1)
        self.config = config
        self.base = Path(base)
        self.start = StartDetector(self.base / config["start_detector"])
        self.targets = {}
        origin = config["reference_client_origin"]
        for name,spec in config["targets"].items():
            roi = StartDetector._box(spec["search_roi_client"])
            arrays = []
            for variant in [spec]+spec.get("variants",[]):
                if "template_image" in variant:
                    # A measured UI state (e.g. hover) may be stored as a tight crop.
                    with Image.open(self.base / variant["template_image"]) as image:
                        template = image.convert("L")
                else:
                    box = StartDetector._box(variant["template_box_client"])
                    with Image.open(self.base / variant["image"]) as image:
                        template = self.crop_reference(image,box,origin).convert("L")
                array = np.array(template)
                if array.std() < 1 or array.shape[1] > roi[2]-roi[0] or array.shape[0] > roi[3]-roi[1]:
                    raise ValueError(f"Invalid template: {name}")
                arrays.append(array)
            self.targets[name] = (arrays,roi,spec["threshold"])
        self.reward_box = StartDetector._box(config["reward"]["received_box_client"])
        with Image.open(self.base / config["reward"]["empty_image"]) as image:
            self.empty = self.crop_reference(image,self.reward_box,origin).convert("RGB")

    @staticmethod
    def crop_reference(image,box,origin):
        area = (box[0]+origin[0],box[1]+origin[1],box[2]+origin[0],box[3]+origin[1])
        if not (0 <= area[0] < area[2] <= image.width and 0 <= area[1] < area[3] <= image.height):
            raise ValueError("ROI outside reference image")
        return image.crop(area)

    def match(self,name,capture):
        templates,roi,threshold = self.targets[name]
        with capture(roi) as image:
            gray = np.array(image.convert("L"))
        if gray.shape != (roi[3]-roi[1],roi[2]-roi[0]):
            raise ValueError("Capture dimensions differ from ROI")
        best = (-1,None,None)
        for template in templates:
            _,score,_,point = cv2.minMaxLoc(cv2.matchTemplate(gray,template,cv2.TM_CCOEFF_NORMED))
            if np.isfinite(score) and score > best[0]:
                best = (score,point,template)
        score,point,template = best
        if point is None:
            return Match(False,0.0,None)
        found = bool(np.isfinite(score) and score >= threshold)
        center = (roi[0]+point[0]+template.shape[1]//2,roi[1]+point[1]+template.shape[0]//2)
        return Match(found,float(score),center if found else None)

    def hud(self,capture):
        with capture(self.start.roi) as image:
            return self.start.inspect(image)

    def change(self,before,after):
        a,b = np.array(before.convert("RGB"),dtype=np.int16),np.array(after.convert("RGB"),dtype=np.int16)
        if a.shape != b.shape:
            raise ValueError("Reward slot image dimensions differ")
        difference = np.max(np.abs(a-b),axis=2)
        fraction = float(np.mean(difference >= self.config["reward"]["change_pixel_delta"]))
        return fraction >= self.config["reward"]["change_fraction"],fraction

    def empty_slot(self,image):
        a,b = np.array(self.empty,dtype=np.int16),np.array(image.convert("RGB"),dtype=np.int16)
        return bool(a.shape == b.shape and np.mean(np.abs(a-b)) <= self.config["reward"]["empty_max_mean_error"])
